import fenics,ufl,dolfin
from dolfin import *
import matplotlib.pyplot as plt
import matplotlib.tri as tri
from common.log import Logger

import copy,time,random
import numpy as np
from scipy import interpolate
from common.baseclasses import AWA
from common import numerics as num
from common import numerical_recipes as numrec

import numbers,ufl
from . import BoxField as BF

#--- Domains and boundaries
def DefaultBoundary(x,on_boundary):
      
    return on_boundary

class PeriodicBoundary1D(SubDomain):
    
    def __init__(self,mesh):
        
        coordsx=mesh.coordinates()[:,0]
        
        self.xmin,self.xmax=np.min(coordsx),np.max(coordsx)
        self.dx=self.xmax-self.xmin
        
        super(type(self),self).__init__()

    # Left boundary is "target domain" G
    def inside(self, x, on_boundary):
        #return bool(x[0] < DOLFIN_EPS and x[0] > -DOLFIN_EPS and on_boundary)
        return fenics.near(x[0],self.xmin) and on_boundary

    # Map right boundary (point `x2`) to left boundary (`x1`)
    def map(self, x1, x2):
        
        x2[0] = x1[0] - self.dx
        
        if len(x1)>1: x2[1]=x1[1]
        if len(x1)>2: x2[2]=x1[2]

class PeriodicBoundary2D(SubDomain):
    """Imposes periodicity in x and y directions"""
    
    def __init__(self,mesh):
        
        coords=mesh.coordinates()
        coordsx=coords[:,0]
        coordsy=coords[:,1]
        
        self.xmin,self.xmax=np.min(coordsx),np.max(coordsx)
        self.dx=self.xmax-self.xmin
        
        self.ymin,self.ymax=np.min(coordsy),np.max(coordsy)
        self.dy=self.xmax-self.ymin
        
        super(type(self),self).__init__()

    # Left boundary is "target domain" G
    def inside(self, x, on_boundary):
        # return True if on left or bottom boundary AND NOT on one of the two corners (0, 1) and (1, 0)
        return bool((near(x[0], self.xmin) or near(x[1], self.ymin)) and 
                (not ((near(x[0], self.xmin) and near(x[1], self.ymax)) or 
                        (near(x[0], self.xmax) and near(x[1], self.ymin)))) and on_boundary)

    def map(self, x1, x2):
        #If we are at corner (1,1), map to (0,0)
        if near(x1[0], self.xmax) and near(x1[1], self.ymax):
            x2[0] = x1[0] - self.dx
            x2[1] = x1[1] - self.dy
        elif near(x1[0], self.xmax):
            x2[0] = x1[0] - self.dx
            x2[1] = x1[1]
        else:   # near(x1[1], 1)
            x2[0] = x1[0]
            x2[1] = x1[1] - self.dy
            
        if len(x1)>2: x2[2]=x1[2]

def getRectBoundary(mesh,where='xmin',eps=1e-9):
    
    coords=mesh.coordinates()
    ndim=len(coords[0])
    
    #Look only at a single dimension to determine proximity to `where`
    if isinstance(where,str):
        if where=='xmax':
            inds=[0]
            where=[np.max(coords[:,inds[0]])]+(ndim-1)*[None]
        elif where=='xmin':
            inds=[0]
            where=[np.min(coords[:,inds[0]])]+(ndim-1)*[None]
            
        elif where=='ymax':
            inds=[1]
            where=[None,np.max(coords[:,inds[0]])]+(ndim-2)*[None]
        elif where=='ymin':
            inds=[1]
            where=[None,np.min(coords[:,inds[0]])]+(ndim-2)*[None]
            
        elif where=='zmax':
            inds=[2]
            where=[None,None,np.max(coords[:,inds[0]])]+(ndim-3)*[None]
        elif where=='zmin':
            inds=[2]
            where=[None,None,np.min(coords[:,inds[0]])]+(ndim-3)*[None]
            
        else: raise ValueError('`where` value "%s" not recognized.'%repr(where))
    
    #Look at dimensions at all indices to determine proximity to `where`
    # But if `None` for any coordinate in `where`, ignore
    # that dimension for determining proximity.
    else:
        inds=[]
        for i,coord in enumerate(where):
            if coord is not None: inds.append(i)
    
    assert len(where)==ndim,\
     '`where` value "%s" should have size equal to mesh dimension = %i.'%(repr(where),ndim)
    
    def square_boundary(x, on_boundary):
        
        near_where=(False not in [fenics.near(x[i],where[i]) for i in inds])
        
        return on_boundary and near_where
    
    return square_boundary

#--- Solvers
def DefaultNewtonSolver():
    
    solver = NewtonSolver()
    solver.parameters["linear_solver"] = "gmres"
    solver.parameters["convergence_criterion"] = "incremental"
    solver.parameters["relative_tolerance"] = 1e-6
    
    return solver

#--- Convenience functions
def coordSymbols(dim=3):
    
    import sympy as sym
    
    return sym.symbols('x[0], x[1], x[2]')[:dim]

def castToFenics(function,V=None,degree=2):
    """
    Cast a function into a `fenics` object type capable of
    being used directly within a UFL form.
    
    The following `function` input types are supported:
    - `fenics.Function` and `fenics.Expression`
    - python function of single variable `x` (a coordinate)
    - `ArrayWithAxes` yields an interpolating expression
    - `str` is interpreted as c++ code string for an expression
    - Constant number yields a fenics `Constant`
    - `sympy` expression in terms of `FenicsTools.coordSymbols`    
    
    Provide a function space `V` if function calls are expected to
    return values of nontrivial shape.  The shape of function
    ouputs will be inferred by the size of the finite element
    attached to `V`.
    
    It's easiest to invoke this utility by way of expressions formed
    from `sympy` symbols.  Any such expressions will be used to
    automatically generate c++ code and thereby a `fenics` 
    `Expression` object."""
    
    try:
        import sympy as sym
        from sympy.core.basic import Basic
        test_sym=True
    except ImportError: test_sym=False
    
    #If we have `ArrayWithAxes`, make into an interpolating function
    # making use of the regular grid of the input
    if isinstance(function,AWA):
        from scipy import interpolate
        assert function.dtype in (np.int,np.float32,np.float64),\
            'If `function` is `ArrayWithAxes` type, data type must be float or integer.'
        function=interpolate.RegularGridInterpolator(function.axes,\
                                                     np.array(function),\
                                                     bounds_error=False,\
                                                     fill_value=None)
    
    #First check if we need to do anything at all
    if isinstance(function,(fenics.Function,\
                            fenics.Expression,\
                            fenics.UserExpression,\
                            ufl.classes.Expr)):
        return function
    
    #If `None` just pass-through
    elif function is None: return function
    
    #Assume a regular python function, cast to `fenics.Expression`
    # Use the provided function space `V` if inference of return
    # value shape is necessary.
    elif hasattr(function,'__call__'):
        # `kwargs` will be passed to the constructor of `Expression`,
        # which `ExpressionFromPyFunc` has inherited.
        if V: kwargs={'element':V.ufl_element()} #untested.
        else: kwargs={}
        return ExpressionFromPyFunc(function,**kwargs)
    
    #Assume a c++ string, cast to `fenics.Expression`
    elif isinstance(function,str):
        return fenics.Expression(function, degree=degree)
    
    #Cast constant numbers to `fenics.Constant`
    elif isinstance(function,(numbers.Number,tuple,list)):
        return fenics.Constant(function)
    
    #Cast `sympy` objects to ccode (assumes symbols are coordinates "x[0],..." etc.)
    elif test_sym and isinstance(function,Basic):
        ccode=sym.printing.ccode(function)
        return fenics.Expression(ccode,degree=degree)
    
    else: raise TypeError("Can't handle type `%s`."%type(function))
    
def relL2Difference(u1,u2,u0=None,min_L2=.01):
    '''
    Find the relative L2 norm difference between two
    `fenics.Function`s using another function `u0`
    as comparator.  If optional `u0` is not provided,
    the average L2 norm of `u1` and `u2` is used
    as comparator.
    
    :param u1: `fenics.Function`
    :param u2: `fenics.Function`
    :param u0: (optional) `fenics.Function`
    
    :returns: Normalized L2 norm difference (`float`)
    '''
    
    L2diff=np.sqrt(fenics.assemble((u1-u2)**2*fenics.dx))
    #one may also use `fenics.errornorm` here but it is overkill
    #in terms of accuracy and seems to recompile every time it is called..
    
    #If a u0 is provided for comparison, use that
    if u0: u0_sq=u0**2
    
    #Otherwise, consider the average of the two functions as comparison
    else: u0_sq=(u1**2+u2**2)/2
    
    L2sum=np.sqrt(fenics.assemble(u0_sq*fenics.dx(u1.function_space().mesh())))
    
    #If the L2 norm of the comparator function is too tiny, compare relative to a minimum value
    if L2sum < min_L2: L2sum=min_L2
    
    return L2diff/L2sum

def get_regular_mesh_size(fenics_mesh):
    
    coords=fenics_mesh.coordinates()
    coords_vals=[list(set(xory_coords)) for xory_coords in coords.T]
    shape=[len(coord_vals) for coord_vals in coords_vals]
    
    assert np.prod(shape)==len(coords), '`fenics_mesh` is not a regular mesh!'
    
    #This is the number of divisions
    return tuple([dimsize-1 for dimsize in shape])

def get_regular_mesh_coords(fenics_mesh):
    
    coords=fenics_mesh.coordinates()
    coords_vals=[sorted(list(set(xory_coords))) for xory_coords in coords.T]
    shape=[len(coord_vals) for coord_vals in coords_vals]
    
    assert np.prod(shape)==len(coords), '`fenics_mesh` is not a regular mesh!'
    
    #This is a mesh of xs, ys, etc.
    return np.meshgrid(*coords_vals,indexing='ij')

#==============================
#--- Expressions and Functions
#==============================

class ExpressionFromPyFunc(fenics.UserExpression):
    """Turn a python function of a one position variable
    into a Fenics `Expression`.
    
    :param function:
        Call-able object; should take argument `x` as a
        rank-1 array.
        
    :returns:
        Fenics `Expression` with the `eval` method tied
        to `function`.
    """
    
    def __init__(self,function,**kwargs):
        
        #Presumably kwargs get passed on to the base class constructor via magic
        self.function=function
        
        super().__init__(self,**kwargs)
        
    def eval(self,value,x):
        
        val=self.function(x)
        
        if hasattr(val,'__len__'): value[:]=val
        else: value[0]=val

class PiecewiseExpression(fenics.UserExpression):
        """Build a (static) `fenics.Expression` that is evaluated based
        on cell-wise values, via a `fenics.MeshFunction`.  The `MeshFunction`
        is constructed automatically with a dictionary of "condition"/"value"
        pairs.
        
            - arg: `mesh`
                `fenics.Mesh` instance over which to build field.
                
            - arg: `conditionalValues`
                `dict` instance with "condition"/"value" pairs.
                Conditions should be either ccode strings (e.g. `"x[0] < 1"`)
                to compile a subdomain, or instances of `fenics.SubDomain`.
                Values should be numeric (float, etc.).  They can also have
                arbitrary shape (e.g. scalar, vector, tensor, etc.).
                
            - kwarg: `defaultValue`
                Value to use as default (background) field value.  Should have
                same shape as values in `conditionalValues`.
                
            - other kwargs:
                Provided to `fenics.CompiledSubDomain` for creation of
                subdomains.  Can provide values to variables referenced in
                c++ code strings.
        """
        
        def __init__(self,mesh,conditionalValues,
                     defaultValue=1,\
                     **kwargs):
            
            assert isinstance(conditionalValues,dict),\
                'Input should be `dict` of "condition"/"value" pairs.'
            
            self.subdomains=[]
            
            self.cellMarker = fenics.MeshFunction('size_t',mesh,mesh.topology().dim())
            self.cellMarker.set_all(0)
            
            #Obtain value shape from shape of the first provided value
            # (e.g. scalar, vector, tensor, etc.)
            self.valueShape=np.array(list(conditionalValues.values())[0]).shape
            
            assert np.array(defaultValue).shape is self.valueShape,\
                '`defaultValue` should have same shape as values: %s'%repr(self.valueShape)
            self.IDvalues={0:defaultValue}
            
            for i,condition in enumerate(conditionalValues):
                
                ID=i+1
                
                if isinstance(condition, fenics.SubDomain):
                    subdomain=condition
                else: subdomain=fenics.CompiledSubDomain(condition,**kwargs)
                
                subdomain.mark(self.cellMarker,ID)
                self.subdomains.append(subdomain)
                
                value=conditionalValues[condition]
                self.IDvalues[ID]=value
                
            super().__init__(self)
            
        def eval_cell(self, values, x, cell):
            
            for ID in self.IDvalues:
                if self.cellMarker[cell.index] == ID:
                    
                    #If we are supposed to return a scalar
                    if not self.valueShape:
                        values[0]=self.IDvalues[ID]
                        
                    #If we are supposed to return a vector etc.
                    # This should simply broadcast over the value shape.
                    else: values[:]=self.IDvalues[ID]
                    
                    return
                    
        def value_shape(self):
            
            try: return self.valueShape
            except AttributeError: return ()

def random_field(mesh,strength=1,seed=1):
    """A function of random values over `mesh`."""
    
    P1 = fenics.FiniteElement("Lagrange", mesh.ufl_cell(), 1)
    V = fenics.FunctionSpace(mesh,P1)
    RF = fenics.Function(V)
    v=RF.vector()
    random.seed(seed)
    randoms=[random.gauss(0,strength) for i in range(len(v))]
    v.set_local(np.array(randoms))
    
    return RF

#=============================
#---- Efficient task functions
#=============================

"""
def projector_timings():
    "
    Demonstration courtesy of M. Mortensen, Dec. 6, 2013.
    
    https://fenicsproject.org/qa/1899/fast-projection-in-case-of-explicit-relations
    "
    
    from dolfin import *
    mesh = RectangleMesh(Point(0,0),Point(1,1),40,40) 
    V = FunctionSpace(mesh,'CG',2)
    u = interpolate(Expression('sin(x[1])*cos(x[0])'), V)
    S = TensorFunctionSpace(mesh,'DG',0)
    
    t0 = Timer("Original")
    H = project(grad(grad(u)), S)
    print(norm(H))
    H.vector().zero()
    
    t0 = Timer("Compress diagonal coefficient matrix  for faster solve")
    A = assemble(inner(TrialFunction(S), TestFunction(S))*dx)
    b = assemble(inner(grad(grad(u)), TestFunction(S))*dx)
    #A.compress()
    solve(A, H.vector(), b, "cg", "default")
    t0.stop()
    print(norm(H))
    H.vector().zero()
    
    t0 = Timer("Extract diagonal from coefficient matrix - solve directly")
    A = assemble(inner(TrialFunction(S), TestFunction(S))*dx)
    b = assemble(inner(grad(grad(u)), TestFunction(S))*dx)
    ones = Function(S)
    ones.vector()[:] = 1
    A_diag = A * ones.vector()
    A_diag.set_local(1.0/A_diag.array())
    H = Function(S)
    H.vector()[:] = b * A_diag
    t0.stop()
    print(norm(H))
    H.vector().zero()
    
    ###
    M = assemble(inner(grad(grad(TrialFunction(V))), TestFunction(S))*dx)
    #M.compress()
    A = assemble(inner(TrialFunction(S), TestFunction(S))*dx)
    ones = Function(S)
    ones.vector()[:] = 1
    A_diag = A * ones.vector()
    A_diag.set_local(1.0/A_diag.array())
    
    t0 = Timer("Extract diagonal + precompute all required")
    b = M*u.vector()
    H.vector()[:] = b * A_diag
    t0.stop()
    print(norm(H))
    
    
    list_timings(); return
    
    #Not sure how to adapt `LocalSolver` operation to current version of dolfin (2016.1.0)
    t0 = Timer("Local Solver")
    ls = LocalSolver(inner(grad(grad(u)), TestFunction(S))*dx)
    
    #return ls
    ls.solve_local(H.vector(), inner(TrialFunction(S), TestFunction(S))*dx)
    t0.stop()
    print(norm(H))
"""
    
class QuickProjector(object):
    
    def __init__(self,V0,V,form=None):
        """Create a fast projector from function space `V0` to `V`.
        
        Optionally, provide a UFL form in terms of a `fenics.TrialFunction(V0)`
        to be applied explicitly and rapidly during any projections into V.
        """
        
        from fenics import assemble,inner,dx,Function,TrialFunction,TestFunction
        dx_V0=dx(V0.mesh())
        dx_V=dx(V.mesh())
        
        self.V0=V0
        self.V=V
        
        #No extra form applied
        if not form: form=TrialFunction(V0)
            
        self.M=assemble(inner(form,TestFunction(V))*dx_V)
        
        A = assemble(inner(TrialFunction(V), TestFunction(V))*dx_V)
        
        ones = Function(V)
        ones.vector()[:] = 1
        self.A_diag = A * ones.vector()
        self.A_diag.set_local(1.0/self.A_diag.get_local()) #might be depreceated towards `.get_local`
        
    def __call__(self,f_in,f_out):
        """Project the input function `f_in` onto the
        output function `f_out`.  These should lie in
        the function spaces `V1` and `V2`, respectively,
        that were used to construct the `QuickProjector`.
        """
    
        #if not f_out: f_out=fenics.Function(self.V2)
    
        b = self.M*f_in.vector()
        f_out.vector()[:] = b * self.A_diag

#==========================================
#--- Meshing, plotting, and post-processing utilities
#==========================================

def StructuredMesh(*axes):
    
    ndim=len(axes)
    assert ndim<=3,'Provide no more than 3 axes (of x, y, z values).'
    
    if ndim==1:
        xs=axes[0]; nx=len(xs)
        mesh=fenics.IntervalMesh(nx-1,0,nx-1)
    elif ndim==2:
        xs,ys=axes; nx=len(xs); ny=len(ys)
        mesh=fenics.RectangleMesh(fenics.Point(0,0),\
                                  fenics.Point(nx-1,ny-1),\
                                  nx-1,ny-1)
    elif ndim==3:
        xs,ys,zs=axes; nx=len(xs); ny=len(ys); nz=len(zs)
        mesh=fenics.BoxMesh(fenics.Point(0,0,0),\
                            fenics.Point(nx-1,ny-1,nz-1),\
                            nx-1,ny-1,nz-1)
    
    coords=mesh.coordinates()
    for vertex,indices in enumerate(coords):
        coords[vertex]=np.array([axes[dim][int(indices[dim])] \
                                 for dim in range(ndim)])
        
    return mesh

class BoxField2(BF.BoxField):
    
    def __init__(self,fenics_function,
                 uniform_mesh=True,**kwargs):
        """
        Turn a DOLFIN P1 finite element field over a structured mesh into
        a BoxField object.
        Standard DOLFIN numbering numbers the nodes along the x[0] axis,
        then x[1] axis, and so on.
    
        If the DOLFIN function employs elements of degree > 1, one should
        project or interpolate the field onto a function space with elements
        of degree=1.
        """
        
        fenics_mesh=fenics_function.function_space().mesh()
        division=get_regular_mesh_size(fenics_mesh)
        
        #only novel thing the constructor does is to build the grid
        if uniform_mesh:
            self.grid = BF.fenics_mesh2UniformBoxGrid(fenics_mesh, division)
        else:
            self.grid = BF.fenics_mesh2BoxGrid(fenics_mesh, division)
        
        assert isinstance(fenics_function,fenics.Function),\
            'constructor argument must be a `fenics.Function`'
        
        self.update_from_fenics_function(fenics_function)
        
        # Store the original function space in case we should use it
        # for future updates of the BoxField, when projecting onto V0
        # could be necessary.
        self.V0=self.function.function_space()
        
    def update_from_fenics_function(self, fenics_function=None, function_space=None):
        """Extracts nodal values of a `fenics_function` and update the
        corresponding vertex values in `box_field`.
        
        If `fenics_function` is an expression or `ufl` form, a function
        will first be projected to the `BoxField`'s native function space
        of suitable (rank-1) vector size, if possible.  This operation
        is not optimized for performance, so it is best if a pre-projected
        `fenics_function` is provided.
        
        Without a function argument, defaults to the
        function used to construct the BoxField."""
            
        if fenics_function is None:
            fenics_function=self.f
        
        else:
            if isinstance(fenics_function,fenics.Function): pass
            
            #If expression or ufl type, we will have to project a function.
            # This is convenient, but not at all efficient, because
            # the projection is an expensive one-off.
            elif isinstance(fenics_function,\
                            (fenics.Expression,ufl.classes.Expr)):
                
                #Check rank and dimension in case of vector quantity
                assert len(fenics_function.ufl_shape) <= 1,\
                            'tensor expressions currently unsupported'
                
                #We will have to project onto a function space.
                if function_space: V=function_space
                
                # Adapt the function space of the original constructor
                # if none is explicitly provided.
                elif fenics_function.ufl_shape != self.V0.ufl_element().value_shape():
                    
                    #Let's make a new mixed element and function space to match the needed vector shape!
                    try:
                        nv=fenics_function.ufl_shape[0]
                        el=fenics.MixedElement([self.V0.ufl_element().sub_elements()[0]]*nv)
                    #Element actually should be neither mixed nor shaped
                    except IndexError: el=self.V0.ufl_element().sub_elements()[0]
                    
                    V=fenics.FunctionSpace(self.V0.mesh(),el)
                    
                else: V=self.V0
                    
                try: fenics_function=fenics.project(fenics_function,V)
                except:
                    print('Could not project expression.  Try explicitly providing a function space.')
                    raise
                
            else: raise TypeError('input type %s not understood'%type(fenics_function))
        
        #Check that we don't have to support some higher order function space
        if fenics_function.ufl_element().degree() != 1:
            raise TypeError("""\
                            The fenics_function2BoxField function works with degree=1 elements
                            only. The DOLFIN function (fenics_function) has finite elements of type
                            %s
                            i.e., the degree=%d != 1. Project or interpolate this function
                            onto a space of P1 elements, i.e.,
                            
                            V2 = FunctionSpace(mesh, 'CG', 1)
                            u2 = project(u, V2)
                            # or
                            u2 = interpolate(u, V2)
                            
                            """ % (str(fenics_function.ufl_element()),\
                                   fenics_function.ufl_element().degree()))
    
        import dolfin
        if dolfin.__version__[:3] == "1.0":
            nodal_values = fenics_function.vector().array().copy()
        else:
            #map = fenics_function.function_space().dofmap().vertex_to_dof_map(fenics_mesh)
            d2v = fenics.dof_to_vertex_map(fenics_function.function_space())
            nodal_values = np.zeros(fenics_function.vector().get_local().shape)
            nodal_values[d2v] = fenics_function.vector().get_local().copy()
    
        if nodal_values.size > self.grid.npoints:
            # vector field, treat each component separately
            ncomponents = int(nodal_values.size/self.grid.npoints)
            vector=ncomponents
            try:
                
                #EDIT: original `BoxField` module had a bug.  Vector functions should be raveled like this:
                nodal_values.shape = (self.grid.npoints,ncomponents)
                #And not like this:
                #nodal_values.shape = (ncomponents, self.grid.npoints)
                
            except ValueError as e:
                raise ValueError('Vector field (nodal_values) has length %d, '%nodal_values.size+\
                                  'there are %d grid points, and this does not match '%self.grid.npoints+\
                                  'with %d components'%ncomponents)
            
            #EDIT: original `BoxField` module had a bug.  Now vector field should be raveled like this:
            vector_field = [BF._rank12rankd_mesh(nodal_values[:,i].copy(),
                                                 self.grid.shape) \
                            for i in range(ncomponents)]
            #And not like this:
            #vector_field = [BF._rank12rankd_mesh(nodal_values[i,:].copy(),
            #                                     self.grid.shape) \
            #                for i in range(ncomponents)]
            
            nodal_values = np.array(vector_field)
        else:
            vector=0
            try:
                nodal_values = BF._rank12rankd_mesh(nodal_values, self.grid.shape)
            except ValueError as e:
                raise ValueError('DOLFIN function has vector of size %s while the '%nodal_values.size+\
                                'provided mesh has %d points and shape %s' % \
                                (self.grid.npoints, self.grid.shape))
        
        #Just use the parent constructor to set everything up,
        # so we don't have to re-implement all the gimickry it performs.
        # This may be a bit cludgy but it works.
        super(BoxField2,self).__init__(self.grid, name=fenics_function.name(),
                                         vector=vector, values=nodal_values)
        
        self.f=self.function=fenics_function
        self.vector=vector
        
    update_from=update_from_fenics_function
    
    # Seems to work also from vector-valued BoxField to vector-valued function; but be vigilent...
    def update_to_function(self, fenics_function=None):
        """
        Simply unpacks the nodal values of the BoxField
        into a 1-dimensional array.  `fenics_function`
        must be able to accept all nodal values
        (e.g. must be vector-valued if BoxField is
        vector-valued, etc.).
        
        Without a function argument, defaults to the
        function used to construct the BoxField,
        simply updating the underlying function values."""
            
        if fenics_function is None:
            fenics_function=self.f
            
        assert isinstance(fenics_function,fenics.Function)
    
        vector=fenics_function.vector()
        nv = len(vector); nb = self.grid.npoints
        if self.vector: nb*=self.vector
        assert nv == nb,\
                '`fenics_function` has %d degrees of freedom, but \
                `box_field` has %d vertex values; these must be be equal.'%(nv,nb)
        
        #vertex labeling of uniform grid uses column-major (Fortran-style) ordering;
        # this also applies to vector indices, which are most interior.
        vertex_values=self.values.flatten('F')
        
        v2d = fenics.vertex_to_dof_map(fenics_function.function_space())
        new_vector=np.zeros((nv,))
        new_vector[v2d] = vertex_values
        
        vector[:]=new_vector
        
    update_to=update_to_function
    
    def to_AWA(self):
        
        axis_names=['X','Y','Z'][:len(self.grid.coor)]
        axes=copy.copy(self.grid.coor)
        
        if self.vector:
            axis_names.insert(0,'Vector index')
            axes.insert(0,list(range(self.vector)))
        
        return AWA(self.values,axes=axes,\
                   axis_names=axis_names)
    
    def __getattribute__(self,attr):
        
        if attr=='AWA': return self.to_AWA()
        
        else: return super(BoxField2,self).__getattribute__(attr)


def vector_component(vector_function,index,V=None):
    
    if not V: V=vector_function.function_space()
    el=V.ufl_element().sub_elements()[0]
    V=fenics.FunctionSpace(V.mesh(),el)
    
    #This could, of course, be implmented in a cached fashion using `QuickProjector`.
    return fenics.project(vector_function[index],V)


class InterpFunction(object):
    
    def __init__(self,function,**kwargs):
        #The goal here is to gather the values of the solution with
        # associated coordinates.  But solution values are only
        # associated with "degree of freedom" indices within the solution.
        # We have to identify each "dof" index with a coordinate.
        
        fn_space=function.function_space()
        mesh=fn_space.mesh()
        self.ndim=mesh.geometry().dim()
        assert self.ndim in [1,2], 'Geometry of the mesh must be 1- or 2-dimensional.'
        
        #Coordinates of mesh cells
        self.points = np.copy(mesh.coordinates())
        
        #This extracts the relevant "DOF" (namely, solution value)
        #    at all points on the mesh, ordered by DOF index.
        #    See: https://fenicsproject.org/qa/5795/plotting-dolfin-solutions-in-matplotlib
        if mesh.num_cells()==function.vector().size():
            #This is how we do it when function space has one DOF per cell, i.e. Lagrange elements
            self.values=np.copy(function.vector().get_local()) #copy the array in case it's read-only etc.
        else: 
            #This is how we do it when function space has more than one DOF per cell
            #    (`function.vector().array()` has inordinate length in this case)
            self.values=function.compute_vertex_values(mesh)
        
        #Which kind of interpolation we use depends on the geometric dimension
        self.limits=[(np.min(self.points[:,i]),\
                      np.max(self.points[:,i])) \
                     for i in range(self.ndim)]
        
        if self.ndim == 1:
            self.interp=interpolate.interp1d(self.points, self.values, **kwargs)
            
        elif self.ndim == 2:
            self.interp=interpolate.LinearNDInterpolator(self.points,
                                                        self.values, **kwargs)
    
    def __call__(self,x):  
        
        x=np.copy(x)
        val=self.interp(x)
        if not val.shape: val=val.tolist()
        
        return val
    
    def limits(self):
        
        limits=[(np.min(self.points[:,i]),\
                 np.max(self.points[:,i])) \
                for i in range(self.ndim)]
        
        return limits
    
    def toAWA(self,axes=None,shape=None):
        
        if self.ndim==1:
            if axes is None and shape is None:
                shape=self.points.shape[0]
                
            if axes is None:
                xmin,xmax=self.limits[0]
                axes=np.linspace(xmin,xmax,shape)
                
            return AWA(self(axes),axes=axes,axis_names=['X'])
        
        #if `self.ndim==2`; this can in principle be extended to `n` dimensions
        if axes is None and shape is None:
            
            dx,dy=[self.limits[0][1]-self.limits[0][0],\
                   self.limits[1][1]-self.limits[1][0]]
            npoints=self.points.shape[0]
            shape=npoints/np.float(dx*dy)*np.array([dx,dy])
            shape=shape.astype(int)
        
        if axes is None:
            axes=[np.linspace(self.limits[i][0],\
                              self.limits[i][1],shape[i]) \
                  for i in range(2)]
        
        if shape is None: shape=tuple([len(axis) for axis in axes])
        
        #Expand axes into 2-d arrays, then unwrap, and feed to interpolator
        xs=np.asarray(axes[0]); ys=np.asarray(axes[1])
        
        xs=np.reshape(xs,(len(xs),1)); xs=np.repeat(xs,shape[1],axis=1)
        ys=np.reshape(ys,(1,len(ys))); ys=np.repeat(ys,shape[0],axis=0)
        
        xs=xs.reshape(np.prod(xs.shape))
        ys=ys.reshape(np.prod(ys.shape))
        interp_points=np.vstack((xs,ys)).T
        
        interp_vals=self.interp(interp_points)
        interp_vals_wrapped=np.reshape(interp_vals,shape)
        
        return AWA(interp_vals_wrapped,axes=axes,axis_names=['X','Y'])

def mesh2triang(mesh):
    """
    See: https://fenicsproject.org/qa/5795/plotting-dolfin-solutions-in-matplotlib
    Courtesy of: `chris_richardson`
    """
    
    xy = mesh.coordinates()
    return tri.Triangulation(xy[:, 0], xy[:, 1], mesh.cells())

def mplot(obj,figure=None):
    """
    Use `matplotlib` to plot one of the following objects:
    
    `obj`:
        - Fenics `Function`
        - Fenics `Mesh`
    
    See: https://fenicsproject.org/qa/5795/plotting-dolfin-solutions-in-matplotlib
    Courtesy of: `chris_richardson`
    """
    
    if not figure: plt.figure()
    else: plt.figure(figure.number)
    
    plt.gca().set_aspect('equal')
    if isinstance(obj, Function):
        mesh = obj.function_space().mesh()
        assert mesh.geometry().dim() == 2,\
            'A `Function` object should be on a 2 dimensional `Mesh`.'
        if obj.vector().size() == mesh.num_cells():
            C = obj.vector().get_local()
            plt.tripcolor(mesh2triang(mesh), C)
        else:
            C = obj.compute_vertex_values(mesh)
            plt.tripcolor(mesh2triang(mesh), C, shading='gouraud')
    elif isinstance(obj, Mesh):
        assert obj.geometry().dim() == 2,\
            'A `Mesh` object should be 2 dimensional.'
        plt.triplot(mesh2triang(obj), color='k')

#=================================
#--- Tools for Elasticity problems
#=================================

def LL_strained_kernelxz(xs=None,zs=None,
                         sigma=.25,E=1.,
                       shape=(101,101),
                       center=(0,0),\
                       Fmag=None):
    """Displacement kernel on elastic surface due to unit traction
    in x-direction at a pixel.  Computed from LL, eq. (8.19)."""
    
    if xs is None or ys is None:
        xs0=np.linspace(-.5,.5,shape[0])
        zs0=np.linspace(-.5,.5,shape[1])
    else:
        shape=(len(xs0),len(zs0))
    
    dx=np.mean(np.diff(xs0))
    dz=np.mean(np.diff(zs0))
    
    if not Fmag: Fmag=1/(dx*dx)
        
    xs=xs0.reshape((shape[0],1))-center[0]
    zs=zs0.reshape((1,shape[1]))-center[1]
    
    rs=np.sqrt(dx*dz+xs**2+zs**2)
    ys=0
    
    ux=(2*(1-sigma)*rs+zs)/(rs*(rs+zs))+(2*rs*(sigma*rs+zs)+zs**2)*xs/(rs**3*(rs+zs)**2)*xs
    uy=(2*rs*(sigma*rs+zs)+zs**2)*xs/(rs**3*(rs+zs)**2)*.1
    
    pref=(1+sigma)/(2*np.pi*E)*Fmag
    ux*=pref
    uy*=pref
    
    where_nan=np.isnan(ux)
    if where_nan.any(): ux[where_nan]=ux[np.isfinite(ux)].max()
    where_nan=np.isnan(uy)
    if where_nan.any(): uy[where_nan]=uy[np.isfinite(uy)].max()
    
    ux[:,zs0<center[1]]=0
    uy[:,zs0<center[1]]=0
    
    return [AWA(u,axes=[xs0,zs0],axis_names=['X','Z']) for u in (ux,uy)]

def LL_strained_kernelxx(xs=None,ys=None,
                         sigma=.25,E=1.,
                       shape=(101,101),
                       center=(0,0),\
                       Fmag=1):
    """Displacement kernel on elastic surface due to unit traction
    in x-direction at a pixel.  Computed from LL, eq. (8.19)."""
    
    if xs is None or ys is None:
        xs=np.linspace(-.5,.5,shape[0])
        ys=np.linspace(-.5,.5,shape[1])
    else:
        xs=xs.squeeze(); ys=ys.squeeze()
        shape=(len(xs),len(ys))
    
    dx=np.min(np.diff(xs))
    dy=np.min(np.diff(ys))
    if not Fmag: Fmag=1/(dx*dy)
        
    xs=xs.reshape((shape[0],1))-center[0]
    ys=ys.reshape((1,shape[1]))-center[1]
    
    #rs=np.sqrt(dx*dy+xs**2+ys**2) #2018.02.17 - `dx*dy` divisor removed for simplicity when checking kernels
    rs=np.sqrt(xs**2+ys**2)
    ux=1/rs*(2*(1-sigma)+2*sigma*xs**2/rs**2)
    
    pref=(1+sigma)/(2*np.pi*E)*Fmag
    ux*=pref
    
    where_nan=np.isnan(ux)+np.isinf(ux)
    if where_nan.any(): ux[where_nan]=ux[np.isfinite(ux)].max()
    
    return AWA(ux,axes=[xs.squeeze(),ys.squeeze()],axis_names=['x','y'])
           
def LL_strained_kernelxy(xs=None,ys=None,
                         sigma=.25,E=1.,
                       shape=(101,101),
                       center=(0,0),\
                       Fmag=1):
    """Displacement kernel on elastic surface due to unit traction
    in x-direction at a pixel.  Computed from LL, eq. (8.19)."""
    
    if xs is None or ys is None:
        xs=np.linspace(-.5,.5,shape[0])
        ys=np.linspace(-.5,.5,shape[1])
    else:
        xs=xs.squeeze(); ys=ys.squeeze()
        shape=(len(xs),len(ys))
    
    dx=np.min(np.diff(xs))
    dy=np.min(np.diff(ys))
    if not Fmag: Fmag=1/(dx*dy)
        
    xs=xs.reshape((shape[0],1))-center[0]
    ys=ys.reshape((1,shape[1]))-center[1]
    
    #rs=np.sqrt(dx*dy+xs**2+ys**2) #2018.02.17 - `dx*dy` divisor removed for simplicity when checking kernels
    rs=np.sqrt(xs**2+ys**2)
    uy=1/rs*(2*sigma*ys*xs/rs**2)
    
    pref=(1+sigma)/(2*np.pi*E)*Fmag
    uy*=pref
    
    where_nan=np.isnan(uy)+np.isinf(uy)
    if where_nan.any(): uy[where_nan]=uy[np.isfinite(uy)].max()
    
    return AWA(uy,axes=[xs.squeeze(),ys.squeeze()],axis_names=['x','y'])

def LL_strained_kernel_fourier_xx(xs=None,ys=None,
                                   sigma=.25,E=1.,
                                   shape=(101,101),
                                   center=(0,0),
                                   Fmag=None,
                                   fmin_mult=1.,fmax_mult=1.):
    """Displacement kernel on elastic surface due to unit traction
    in x-direction at a pixel.  Computed in fourier space for
    periodic system, according to LL, eqs. (8.11) and (8.12).
    
    Far from boundary, agrees quantitatively with real-space computed kernel."""
    
    if xs is None or ys is None:
        xs=np.linspace(-.5,.5,shape[0])
        ys=np.linspace(-.5,.5,shape[1])
    else:
        xs=xs.squeeze(); ys=ys.squeeze()
        shape=(len(xs),len(ys))
    
    dx=np.mean(np.diff(xs))
    dy=np.mean(np.diff(ys))
    
    if not Fmag: Fmag=1
    
    center_coord=[np.argmin((coor-center[i])**2) \
                    for i,coor in enumerate((xs,ys))]
    
    kmin=2*np.pi*fmin_mult
    kmax=2*np.pi*1/np.sqrt(dx*dy)*fmax_mult
    
    #We want delta to have an L1 norm equal to Fmag
    delta=AWA(np.zeros(shape),axes=[xs,ys])
    delta[tuple(center_coord)]=Fmag/(dx*dy)
    s_d=num.Spectrum(num.Spectrum(delta,axis=0),axis=1)
    
    kxs,kys=s_d.axis_grids
    kxs*=2*np.pi; kys*=2*np.pi
    ks=np.sqrt(kxs**2+kys**2)#+kmin**2)
    
    s_ux=-sigma*kxs**2/ks**3+1/ks #sign is correct according to simulation
    s_uy=-sigma*kxs*kys/ks**3
    s_ux[np.isnan(s_ux)]=0#
    s_uy[np.isnan(s_uy)]=0#
    
    pref=2*(1+sigma)/E
    s_ux*=pref
    s_uy*=pref
    
    # Weighting factor of L2 norm = 1 to suppress high frequencies
    weight=np.exp(-ks/kmax)
    weight/=np.sqrt(np.mean(weight**2))
    weight=1 #2018.02.17 - removed for simplicity when checking kernels
    
    #Convolve through multiplication of spectra
    ux=(s_d*s_ux*weight).get_inverse(axis=0,origin=xs[0],offset=xs[0])\
                        .get_inverse(axis=1,origin=ys[0],offset=ys[0]).real
    uy=(s_d*s_uy*weight).get_inverse(axis=0,origin=xs[0],offset=xs[0])\
                        .get_inverse(axis=1,origin=ys[0],offset=ys[0]).real
    norm = (np.prod([max-min for max, min in ux.axis_limits]))**(1/3.)
    ux*=norm
    uy*=norm
    
    #DC value of ux is difficult to reconcile in Fourier representation;
    # just make minimum value zero
    ux-=ux.min()
    
    return ux

def LL_strained_kernel_fourier_xy(xs=None,ys=None,
                                   sigma=.25,E=1.,
                                   shape=(101,101),
                                   center=(0,0),
                                   Fmag=None,
                                   fmin_mult=1.,fmax_mult=1.):
    """Displacement kernel on elastic surface due to unit traction
    in x-direction at a pixel.  Computed in fourier space for
    periodic system, according to LL, eqs. (8.11) and (8.12).
    
    Far from boundary, agrees quantitatively with real-space computed kernel."""
    
    if xs is None or ys is None:
        xs=np.linspace(-.5,.5,shape[0])
        ys=np.linspace(-.5,.5,shape[1])
    else:
        xs=xs.squeeze(); ys=ys.squeeze()
        shape=(len(xs),len(ys))
    
    dx=np.mean(np.diff(xs))
    dy=np.mean(np.diff(ys))
    
    if not Fmag: Fmag=1
    
    center_coord=[np.argmin((coor-center[i])**2) \
                    for i,coor in enumerate((xs,ys))]
    
    kmin=2*np.pi*fmin_mult
    kmax=2*np.pi*1/np.sqrt(dx*dy)*fmax_mult
    
    #We want delta to have an L1 norm equal to Fmag
    delta=AWA(np.zeros(shape),axes=[xs,ys])
    delta[tuple(center_coord)]=Fmag/(dx*dy)
    s_d=num.Spectrum(num.Spectrum(delta,axis=0),axis=1)
    
    kxs,kys=s_d.axis_grids
    kxs*=2*np.pi; kys*=2*np.pi
    ks=np.sqrt(kxs**2+kys**2+kmin**2)
    
    s_ux=-sigma*kxs**2/ks**3+1/ks #sign is correct according to simulation
    s_uy=-sigma*kxs*kys/ks**3
    
    pref=2*(1+sigma)/E
    s_ux*=pref
    s_uy*=pref
    
    # Weighting factor of L2 norm = 1 to suppress high frequencies
    weight=np.exp(-ks/kmax)
    weight/=np.sqrt(np.mean(weight**2))
    weight=1 #2018.02.17 - removed for simplicity when checking kernels
    
    #Convolve through multiplication of spectra
    ux=(s_d*s_ux*weight).get_inverse(axis=0,origin=xs[0],offset=xs[0])\
                        .get_inverse(axis=1,origin=ys[0],offset=ys[0]).real
    uy=(s_d*s_uy*weight).get_inverse(axis=0,origin=xs[0],offset=xs[0])\
                        .get_inverse(axis=1,origin=ys[0],offset=ys[0]).real
    norm = (np.prod([max-min for max, min in ux.axis_limits]))**(1/3.)
    ux*=norm
    uy*=norm
    
    #DC value of ux is difficult to reconcile in Fourier representation;
    # just make minimum value zero
    ux-=ux.min()
    
    return uy
#===============================
#--- Static Problem (SP) Solvers
#===============================

def PoissonDirichletSP(mesh,boundaryFunction,\
                              boundaryLocation=DefaultBoundary,
                              sourceFunction=0,\
                              epsilonFunction=1,\
                              constrainedDomain=None,\
                              degree=2):
    
    #--- Get a default boundary identifier if needed
    if boundaryLocation is None: boundaryLocation=DefaultBoundary
    
    #--- Function space
    #Incorporate constrained boundaries into function space, and
    # use "Continuous Galerkin" elements (standard, same as "Lagrange")
    V = fenics.FunctionSpace(mesh, "CG", 1,
                             constrained_domain=constrainedDomain)
    u = fenics.TrialFunction(V)
    v = fenics.TestFunction(V)
    
    #--- Instantiate the Dirichlet boundary
    boundaryFunction = castToFenics(boundaryFunction,degree=degree)
    bc = fenics.DirichletBC(V, boundaryFunction,
                            boundaryLocation)
    
    #--- Define variational problem
    eps = castToFenics(epsilonFunction,degree=degree)
    f = castToFenics(sourceFunction,degree=degree)
    
    from fenics import dot,grad,dx
    a = eps*dot(grad(u), grad(v))*dx
    L = f*v*dx
    
    #--- Compute solution
    soln = fenics.Function(V)
    fenics.solve(a == L, soln, bc)
    
    return soln

def PoissonSP(mesh,value_boundaries,source_boundaries=None,
              boundary_values=None,boundary_sources=None,
              body_source=None,body_force_domain=None,
              epsilon=1,degree=2,\
              constrained_domain=None,\
              solver_parameters=None,\
              form_compiler_parameters=None):
    
    global domain_markers
    
    # Define function space
    P1 = fenics.FiniteElement("Lagrange", mesh.ufl_cell(), 1)
    V = fenics.FunctionSpace(mesh, P1, constrained_domain=constrained_domain)
    
    #--- Boundary values
    #One or more value boundaries need to be specified (to fix zero for displacement)
    if not value_boundaries: value_boundaries=[]
    elif not isinstance(value_boundaries,(tuple,list)):
        value_boundaries=[value_boundaries]
        
    # Define boundary condition on displacement
    if not isinstance(boundary_values,(tuple,list)):
        boundary_values=[boundary_values]*len(value_boundaries)
    for i,item in enumerate(boundary_values):
        if item: boundary_values[i]=castToFenics(item,V=V)
        else: boundary_values[i]=fenics.Constant(0)
    
    bcs = [DirichletBC(V, boundary_value, value_boundary) \
           for boundary_value,value_boundary \
           in zip(boundary_values,value_boundaries)]
    
    #--- Source boundaries
    if source_boundaries:
        if not isinstance(source_boundaries,(tuple,list)):
            source_boundaries=[source_boundaries]
    else: source_boundaries=[]
    
    #Mark the traction boundaries
    class SourceBoundary(fenics.SubDomain):
            
        def __init__(self,source_boundary):
            self.source_boundary=source_boundary
            super(type(self),self).__init__()
                
        def inside(self, x, on_boundary):
            return bool(self.source_boundary(x,on_boundary))
        
    boundary_markers = fenics.MeshFunction('size_t', mesh, mesh.topology().dim() - 1)
    boundary_markers.set_all(0)
        
    if source_boundaries:
        for i,source_boundary in enumerate(source_boundaries):
            TB=SourceBoundary(source_boundary)
            TB.mark(boundary_markers,i+1)
    
    ds = fenics.Measure('ds', domain=mesh, subdomain_data=boundary_markers)
    
    #Make sure associated boundary tractions are fenics-compatible n-vectors
    if not isinstance(boundary_sources,(tuple,list)):
        boundary_sources=[boundary_sources]*len(source_boundaries)
    for i in range(len(boundary_sources)):
        if boundary_sources[i]: boundary_sources[i]=castToFenics(boundary_sources[i],V=V)
        else: boundary_sources[i]=fenics.Constant(0)
    
    #Define body source
    if body_source:
        f=castToFenics(body_source,V=V)
    else: f=fenics.Constant(0)
    
    domain_markers=fenics.MeshFunction('size_t',mesh,mesh.topology().dim())
    domain_markers.set_all(1)
    if body_force_domain:
        domain_markers.set_all(0)
        if isinstance(body_force_domain,str):
            body_force_domain=fenics.CompiledSubDomain(body_force_domain)
        body_force_domain.mark(domain_markers,1)
    dx=fenics.Measure('dx',domain=mesh,subdomain_data=domain_markers)
    
    # Define epsilon function
    eps = castToFenics(epsilon,degree=degree)
    
    # Define variational problem
    from fenics import TrialFunction,TestFunction,inner,dot,grad,Function,solve
    
    u = TrialFunction(V)
    v = TestFunction(V)
    a = eps*dot(grad(u), grad(v))*dx
    n = fenics.FacetNormal(mesh)
    a+= eps*inner(n,grad(u))*v*ds(0)
            
    L = f*v*dx(1)
    #Add sources at appropriate boundaries
    for i,Q in enumerate(boundary_sources):
        L+=Q*v*ds(i+1)
        
    # Compute solution
    if not solver_parameters: solver_parameters={"linear_solver": "gmres"}
    if not solver_parameters: solver_parameters={"optimize": True,\
                                                 'cpp_optimize':True,\
                                                 'representation':'uflacs'}
    
    # Compute solution
    soln = Function(V)
    solve(a == L, soln, bcs, solver_parameters=solver_parameters,\
          form_compiler_parameters=form_compiler_parameters)
    
    return soln

def ElasticSP(mesh,clamped_boundaries,traction_boundaries=None,
              clamped_displacements=None,boundary_tractions=None,
              body_force=None,body_force_domain=None,
              nu=.25,E=1,
              constrained_domain=None,\
              solver_parameters=None,\
              form_compiler_parameters=None):
    
    global domain_markers
    
    #Compute Lame parameters from Poisson's ratio (`nu`)
    # and bulk modulus (`E`)
    mu=E/(2*(1+nu))
    lambda_=E*nu/((1+nu)*(1-2*nu))
    
    coords=mesh.coordinates()
    ndim=len(coords[0])
    
    # Define function space
    P1 = fenics.FiniteElement("Lagrange", mesh.ufl_cell(), 1)
    Pn = fenics.MixedElement([P1]*ndim)
    #V0 = fenics.FunctionSpace(mesh, 'P', 1,\
    #                          constrained_domain=constrained_domain)
    #V = fenics.MixedFunctionSpace([V0]*ndim)
    V = fenics.FunctionSpace(mesh, \
                             fenics.MixedElement([P1]*ndim), \
                             constrained_domain=constrained_domain)
    
    #--- Displacement boundaries
    #One or more clamped boundaries need to be specified (to fix zero for displacement)
    if not clamped_boundaries: clamped_boundaries=[]
    elif not isinstance(clamped_boundaries,(tuple,list)):
        clamped_boundaries=[clamped_boundaries]
        
    # Define boundary condition on displacement
    if not isinstance(clamped_displacements,(tuple,list)):
        clamped_displacements=[clamped_displacements]*len(clamped_boundaries)
    for i,item in enumerate(clamped_displacements):
        if item: clamped_displacements[i]=castToFenics(item,V=V)
        else: clamped_displacements[i]=fenics.Constant((0,)*ndim)
    
    bcs = [DirichletBC(V, clamped_displacement, clamped_boundary) \
           for clamped_displacement,clamped_boundary \
           in zip(clamped_displacements,clamped_boundaries)]
    
    #--- Traction boundaries
    # If provided boundaries for traction, define boundary condition on stress (boundary traction)
    if traction_boundaries:
        if not isinstance(traction_boundaries,(tuple,list)):
            traction_boundaries=[traction_boundaries]
    else: traction_boundaries=[]
    
    #Mark the traction boundaries
    class TractionBoundary(fenics.SubDomain):
            
        def __init__(self,traction_boundary):
            self.traction_boundary=traction_boundary
            super(type(self),self).__init__()
                
        def inside(self, x, on_boundary):
            return bool(self.traction_boundary(x,on_boundary))
        
    if traction_boundaries:
        boundary_markers = fenics.MeshFunction('size_t', mesh, mesh.topology().dim() - 1)
        for i,traction_boundary in enumerate(traction_boundaries):
            TB=TractionBoundary(traction_boundary)
            TB.mark(boundary_markers,i+1)
    else: boundary_markers=None
    
    ds = fenics.Measure('ds', domain=mesh, subdomain_data=boundary_markers)
    
    #Make sure associated boundary tractions are fenics-compatible n-vectors
    if not isinstance(boundary_tractions,(tuple,list)):
        boundary_tractions=[boundary_tractions]*len(traction_boundaries)
    for i in range(len(boundary_tractions)):
        if boundary_tractions[i]: boundary_tractions[i]=castToFenics(boundary_tractions[i],V=V)
        else: boundary_tractions[i]=fenics.Constant((0,)*ndim)
        
    
    """
    if boundary_traction:
        T=castToFenics(boundary_traction,V=V)
    else: T=fenics.Constant((0,)*ndim)
        
    if traction_boundaries:
        if not isinstance(traction_boundaries,(tuple,list)):
            traction_boundaries=[traction_boundaries]
        
        #Mark boundaries for traction
        class TractionBoundary(fenics.SubDomain):
            
            def __init__(self,traction_boundaries):
                self.traction_boundaries=traction_boundaries
                super(type(self),self).__init__()
                
            def inside(self, x, on_boundary):
                return bool(np.sum([traction_boundary(x,on_boundary) for \
                                    traction_boundary in self.traction_boundaries]))
        
        TB=TractionBoundary(traction_boundaries)
        boundary_markers = fenics.FacetFunction('size_t', mesh)
        TB.mark(boundary_markers,1)
    
    else: boundary_markers=None
    """
    
    #Define body force
    if body_force:
        f=castToFenics(body_force,V=V)
    else: f=fenics.Constant((0,)*ndim)
    
    domain_markers=fenics.MeshFunction('size_t',mesh,mesh.topology().dim())
    domain_markers.set_all(1)
    if body_force_domain:
        domain_markers.set_all(0)
        if isinstance(body_force_domain,str):
            body_force_domain=fenics.CompiledSubDomain(body_force_domain)
        body_force_domain.mark(domain_markers,1)
    dx=fenics.Measure('dx',domain=mesh,subdomain_data=domain_markers)
    
    # Define strain and stress
    def epsilon(u):
        del_u=fenics.nabla_grad(u)
        return 0.5*(del_u + del_u.T)
        #return sym(nabla_grad(u))
        
    def sigma(u):
        return lambda_*fenics.nabla_div(u)*fenics.Identity(d) \
                 + 2*mu*epsilon(u)
    
    # Define variational problem
    from fenics import TrialFunction,TestFunction,inner,dot,Function,solve
    
    u = TrialFunction(V)
    d = u.geometric_dimension()  # space dimension
    v = TestFunction(V)
    a = inner(sigma(u), epsilon(v))*dx
    L = dot(f, v)*dx(1)
    #Add tractions at appropriate boundaries
    for i,T in enumerate(boundary_tractions):
        L+=dot(T, v)*ds(i+1)
    # Compute solution
    u = Function(V)
    
    if not solver_parameters: solver_parameters={"linear_solver": "gmres"}
    if not solver_parameters: solver_parameters={"optimize": True,\
                                                 'cpp_optimize':True,\
                                                 'representation':'uflacs'}
    
    solve(a == L, u, bcs, solver_parameters=solver_parameters,\
          form_compiler_parameters=form_compiler_parameters)
    
    return u

#========================================
#--- Time Dependent Problem (TDP) Solvers
#========================================

def default_free_energy(c):
    
    a=10. #double-well energy
    
    return (a**2/2.)*c**2*(1-c)**2

# Class representing initial conditions
class InitialConditions(UserExpression):
    
    def __init__(self,composition, noise=.02, seed=1, **kwargs):
        
        self._composition=composition
        self._noise=noise
        self._seed=seed
        self._seeded=False
        
        super().__init__(self)
        
    def eval(self, values, x):
        
        if not self._seeded: random.seed(self._seed); self._seeded=True
        values[0] = self._composition + random.gauss(0,self._noise)
        values[1] = 0.0
        
    def value_shape(self):
        return (2,)

class CahnHilliardTDP(fenics.NonlinearProblem):
    
    def __init__(self, mesh, initial_concentration,\
                 free_energy=None,\
                 field=None,\
                 kappa=1e-3,\
                 dt0=1e-7,\
                 theta=.5,\
                 constrained_domain=None,\
                 boundary_values=[],
                 boundary_locations=[],
                 **kwargs):
    
        fenics.NonlinearProblem.__init__(self)
        self.optimize_compiler()
        
        self.mesh=mesh
        P1 = fenics.FiniteElement("Lagrange", mesh.ufl_cell(), 1)
        self.V = fenics.FunctionSpace(mesh, P1*P1,\
                                 constrained_domain=constrained_domain)
        
        #--- build Dirichlet boundary conditions (only for concentration!)
        assert len(boundary_values)==len(boundary_locations)
        self.bcs=[fenics.DirichletBC(self.V.sub(0),bv,bl) for bv,bl \
                  in zip(boundary_values,boundary_locations)]
        
        #--- Define trial and test functions
        self.du    = fenics.TrialFunction(self.V)
        self.q, self.v  = fenics.TestFunctions(self.V)
        
        #--- Define functions
        self.u   = fenics.Function(self.V)  # current solution
        self.u0  = fenics.Function(self.V)  # solution from previous converged step
        
        self.update_initial(initial_concentration)
        self.u.vector()[:]=self.u0.vector() #start looking for solution near initial concentration
        
        #--- Split mixed functions
        c,  mu  = fenics.split(self.u)
        
        #--- Define free energy function
        c = fenics.variable(c) #It's important that c is declared a variable before invoking expressions with it
        if free_energy is None: self.free_energy=default_free_energy(c)
        else: self.free_energy=free_energy
        f=self.free_energy(c)
        
        #--- Add random field
        if field is not None:
            field = castToFenics(field, degree=1)
            
            #If we have cast to `fenics.Expression`, might as well build a function from it
            if isinstance(field,(fenics.Expression,fenics.UserExpression)):
                print('Building function from field...')
                Field=fenics.Function(fenics.FunctionSpace(mesh,P1,\
                                                        constrained_domain=constrained_domain))
                Field.interpolate(field)
            else: Field=field
                
            f+=Field*c
            
        # Compute the chemical potential df/dc
        self.dfdc = fenics.diff(f, c)
        
        self.dt=fenics.Constant(dt0)
        self.t=fenics.Constant(0)
        
        self.theta=theta
        self.kappa=kappa
        
        #Set the equations
        self.set_equations(**kwargs)
        
        #--- Compute directional derivative about u in the direction of du (Jacobian)
        self.j = fenics.derivative(self.L, self.u, self.du)
    
    def set_equations(self,**kwargs):
        
        dc, dmu = fenics.split(self.du)
        c0, mu0 = fenics.split(self.u0)
        c,  mu  = fenics.split(self.u)
        
        #--- Weak statement of the equations
        from fenics import dx,grad,dot
        mu_mid = (1.0-self.theta)*mu0 + self.theta*mu
        
        #Turn this on to add a Cahn-Allen component to dynamics
        CA_pref=0 #+CA_pref*mu_mid*self.q
        
        L0 = c*self.q*dx - c0*self.q*dx + self.dt*(dot(grad(mu_mid), grad(self.q)))*dx
        L1 = mu*self.v*dx - self.dfdc*self.v*dx - self.kappa*dot(grad(c), grad(self.v))*dx
        self.L = L0 + L1
        
    @staticmethod
    def optimize_compiler():
        
        # Form compiler options
        fenics.parameters["form_compiler"]["optimize"]     = True
        fenics.parameters["form_compiler"]["cpp_optimize"] = True
        fenics.parameters["form_compiler"]["representation"] = "uflacs"

    def F(self, b, x):
        fenics.assemble(self.L, tensor=b)
        #apply boundary conditions
        for bc in self.bcs: bc.apply(b, x)
        
    def J(self, A, x):
        fenics.assemble(self.j, tensor=A)
        #apply boundary conditions
        for bc in self.bcs: bc.apply(A)
    
    def vector(self): return self.u.vector()
    
    def update_initial(self,initial):
        
        #update u0 from another vector (e.g., from a previous solution vector)
        if isinstance(initial,\
                      dolfin.GenericVector): #EDITED 2018.07.29 - path to `GenericVector` changed for fenics 2018.1.0
            #Let's assume the provided vector has both concentration and chemical potential
            self.u0.vector()[:]=initial
            
        #update u0 with values of concentration from an array
        elif isinstance(initial,np.ndarray):
            #collapse gives the actual function space, rather than a view to it
            Vc=self.u0.sub(0).function_space().collapse()
            c0=fenics.Function(Vc)
            if len(initial.shape)==1: c0.vector()[:]=initial
            else:
                bf_init=BoxField2(c0)
                bf_init.values=initial
                bf_init.update_to()
                c0=bf_init.function
            fenics.assign(self.u0.sub(0),c0)
        
        else:
            import numbers
            
            if isinstance(initial,(fenics.Expression,\
                                   fenics.UserExpression)):
                init=initial
            
            #Build a rank-1 expression from c++ code string
            elif isinstance(initial,str):
                init=fenics.Expression((initial,'0'),degree=1)
                
            #If a constant, just use a constant expression
            elif isinstance(initial,numbers.Number):
                init=fenics.Constant((initial,0))
                
            #Wrap any function into a rank-1 expression
            elif hasattr(initial,'__call__'):
                
                class Init(UserExpression):
                    def eval(self,values,x):
                        values[0]=initial(x)
                        values[1]=0.
                    def value_shape(self): return (2,)
                
                init=Init(degree=1)
                
            else: raise TypeError('`initial` type %s not understood.'%type(initial))
                
            #self.u0.interpolate(init)
            self.u0=fenics.interpolate(init,self.V)
    
    def update_time(self,t): self.t.assign(t)
    
    def update_dt(self,dt): self.dt.assign(dt)
    
    def get_concentration(self):
        
        #This is meant to circumvent the error: "Duplication of MPI communicator failed"
        while True:
            try: return self.u.split(deepcopy=True)[0]
            except RuntimeError: continue
    
    def get_chemical_potential(self):
        
        #This is meant to circumvent the error: "Duplication of MPI communicator failed"
        while True:
            try: return self.u.split(deepcopy=True)[1]
            except RuntimeError: continue
    
    get_soln=get_concentration

class CahnAllenTDP(CahnHilliardTDP):
        
    def set_equations(self,**kwargs):
        
        dc, dmu = fenics.split(self.du)
        c0, mu0 = fenics.split(self.u0)
        c,  mu  = fenics.split(self.u)
        
        #--- Weak statement of the equations
        from fenics import dx,grad,dot
        mu_mid = (1.0-self.theta)*mu0 + self.theta*mu
        
        L0 = c*self.q*dx - c0*self.q*dx + self.dt*mu_mid*self.q*dx
        L1 = mu*self.v*dx - self.dfdc*self.v*dx - self.kappa*dot(grad(c), grad(self.v))*dx
        self.L = L0 + L1

class CahnAllenStrainedTDP(CahnAllenTDP):
        
    def __init__(self, mesh, initial_concentration, 
                 mesh_size=None,
                 free_energy=None, 
                 field=None, 
                 kappa=1e-3,dt0=1e-7,theta=.5, 
                 constrained_domain=None,
                 boundary_values=[],
                 boundary_locations=[],
                 Phis=[1,1],
                 PhiVecs=[[1,0],[0,1]],
                 sigma=.25,E=1,
                 Uxx_kernel=LL_strained_kernel_fourier_xx,
                 Uxy_kernel=LL_strained_kernel_fourier_xy,
                 fourier_kernels=False,
                 pad_convolution_by=None,
                 boundary_conditions=None,
                 surface_terms=False,
                 **kwargs):
        
        super(CahnAllenStrainedTDP,\
              self).__init__(mesh, initial_concentration,\
                              free_energy=free_energy, field=field,\
                              kappa=kappa, dt0=dt0, theta=theta,\
                              constrained_domain=constrained_domain,\
                              boundary_values=boundary_values,boundary_locations=boundary_locations,\
                              Phis=Phis,PhiVecs=PhiVecs,surface_terms=surface_terms)
        
        #Function space V0 is needed since constrained domain is not compatible with BoxField.
        # No problem, functions will be projected from the constrained function space anyway.
        P1 = fenics.FiniteElement("Lagrange", mesh.ufl_cell(), 1)
        self.V0 = fenics.FunctionSpace(mesh, P1*P1) # same as `self.V`, but without constrained domain
        
        # 2-element vector function BoxField for surface traction
        self.bf_traction=BoxField2(fenics.Function(self.V0),division=mesh_size)
        
        # 2-element vector function BoxField for surface displacement
        self.bf_u=BoxField2(fenics.Function(self.V0),division=mesh_size)
        
        #--- Integral measures for convolutions
        xs,ys=self.bf_u.grid.coor
        self.dx=np.mean(np.diff(xs)) #this is assuming a uniform grid (needed for convolution)
        self.dy=np.mean(np.diff(ys))
        
        #--- Quick Projectors
        # quick projector to compute traction in the BoxField function space
        # 2018.03.13 - minus sign added before `self.PhiMat` to accord with sign of body force
        #              in thin film setting of the elasticity problem
        print(self.PhiMat)
        self.updateTraction=QuickProjector(self.V,self.V0,\
                                           form=-self.PhiMat*fenics.grad(fenics.TrialFunction(self.V)[0]))
        
        # quick projector to put the displacement back in constrained function space
        self.projectDisplacement=QuickProjector(self.V0,self.V)
        
        self.set_displacement_convolvers(Uxx_kernel=Uxx_kernel,\
                                         Uxy_kernel=Uxy_kernel,\
                                         Uyx_kernel=None,Uyy_kernel=None,\
                                         fourier_kernels=fourier_kernels,\
                                         boundary_conditions=boundary_conditions,\
                                         pad_convolution_by=pad_convolution_by,\
                                         **kwargs)
        self.update_displacement()
        
    def set_equations(self,Phis,PhiVecs,surface_terms=True):
        
        # Build strain-coupling Phi matrix
        Q=np.matrix(PhiVecs).T
        Lambda=np.matrix(np.diag(Phis))
        # EDIT: 2017.05.12 - Minus sign added to definition of Phi matrix, because
        # stress equilibrium in the medium requires a force of "negative grad"
        # times "delta stress" from order parameter, so prefactor ('Phi') is negative
        #PhiMat=-Q*Lambda*Q.I
        # EDIT: 2018.03.14 - Minus sign removed - stress equilibrium in the medium enforced by 
        #                    "minus" in front of grad in the definition of force for `self.updateTraction`.
        PhiMat=+Q*Lambda*Q.I
        self.PhiMat=fenics.as_matrix(PhiMat.tolist())
        
        #Add displacement vector function
        self.displacement = fenics.Function(self.V)
        
        dc, dmu = fenics.split(self.du)
        c0, mu0 = fenics.split(self.u0)
        self.c,  mu  = fenics.split(self.u)
        
        #--- Weak statement of the equations
        from fenics import dx,grad,dot,div,inner
        mu_mid = (1.0-self.theta)*mu0 + self.theta*mu
        
        L0 = self.c*self.q*dx - c0*self.q*dx + self.dt*mu_mid*self.q*dx
        # 2017.04.03 - mistaken factor of `1/2.` removed from last (non-local) term in Euler-Lagrange equations
        # 2018.03.13 - minus sign removed before `self.PhiMat` to accord with sign of elastic energy term
        #              in thin film setting of the elasticity problem
        L1 = mu*self.v*dx - self.dfdc*self.v*dx - self.kappa*dot(grad(self.c), grad(self.v))*dx \
                + div(self.PhiMat*self.displacement)*self.v*dx # strain term added last...
        
        self.surface_terms=surface_terms
        if self.surface_terms:
            #2017.05.16 - added surface term to allow "open" boundaries (normal derivative need not vanish)
            n = fenics.FacetNormal(self.mesh)
            L1+= self.kappa*inner(grad(self.c),n)*self.v*ds
            
        self.L = L0 + L1
        
    def set_displacement_convolvers(self,Uxx_kernel,Uxy_kernel,\
                                    Uyx_kernel=None,Uyy_kernel=None,\
                                    fourier_kernels=False,\
                                    boundary_conditions={},\
                                    pad_convolution_by=None,**kwargs):
        
        from . import Elasticity as El
        
        if pad_convolution_by is None:
            #Boundary conditions are implemented exactly only when we have overall
            #periodicity of twice the computational cell, which is enabled by
            #padding 0.5 on each side.
            if boundary_conditions: pad_convolution_by=0.5
            
            #No reason to add computational expense to convolution if padding not requested.
            #This is also the right choice if periodic boundaries are chosen
            else: pad_convolution_by=0
        
        Logger.write("Boundary conditions to be used on Green's dyadic functions: %s"%boundary_conditions)
        Logger.write('\tPadding convolution by %s.'%pad_convolution_by)
        
        #--- Kernels
        #Compute displacement kernels from x-directed traction
        #Shift evaluation axes of kernel to center at zero, so conventional
        # kernel evaluators will not truncate negative axis values
        xs,ys=self.bf_u.grid.coor
        shape=(len(xs),len(ys))
        size=(np.max(xs)-np.min(xs),\
              np.max(ys)-np.min(ys))
        
        #Infer the kernels for y-oriented force by rotation
        #2018.02.14 - This is already default functionality inside StrainConvolver2D`
        #if Uyx_kernel is None: Uyx_kernel=El.Uyx_kernel_from_Uxy(Uxy_kernel)
        #if Uyy_kernel is None: Uyy_kernel=El.Uyy_kernel_from_Uxx(Uxx_kernel)
        
        Logger.write('Fourier kernels? %s'%fourier_kernels)
        self.strain_convolver=El.StrainConvolver2D(Uxx_kernel=Uxx_kernel,\
                                                   Uxy_kernel=Uxy_kernel,\
                                                   Uyx_kernel=Uyx_kernel,\
                                                   Uyy_kernel=Uyy_kernel,\
                                                   fourier_kernels=fourier_kernels,\
                                                   shape=shape,size=size,\
                                                   boundary_conditions=boundary_conditions,\
                                                   pad_by=pad_convolution_by,**kwargs)
        
        #2018.02.18 - Added for debug purposes
        self.debug_auxfield=False
        if self.debug_auxfield:
            #mesh=self.V.get_mesh()
            #P1 = fenics.FiniteElement("Lagrange", mesh.ufl_cell(), 1)
            #V_P1 = fenics.FunctionSpace(mesh, P1) # same as `self.V`, but without constrained domain
            V_P1=self.V.sub(0).collapse()
            self.updateAuxField=QuickProjector(self.V,V_P1,\
                                               form=-fenics.div(self.PhiMat*fenics.TrialFunction(self.V)))
            self.bf_auxfield=BoxField2(fenics.Function(V_P1))

    def update_displacement(self):
        
        #--- Update the stress field
        # Form will be automatically projected to function space `self.V0`
        self.updateTraction(self.u0,self.bf_traction.f)
        self.bf_traction.update_from()
        traction_x,traction_y=self.bf_traction.values
        
        #--- Compute displacements
        # convolving traction with kernels
        ux,uy=self.strain_convolver(traction_x,traction_y)
        norm=1#/(self.dx*self.dy)
        ux*=norm; uy*=norm
            
        # turn the convolution sum into an integral using integral measure on pixels
        #ux*=self.dx*self.dy
        #uy*=self.dx*self.dy
        
        #--- Update the displacement field and functions
        self.bf_u.values[0,:]=ux
        self.bf_u.values[1,:]=uy
        self.bf_u.update_to() #This updates the underlying displacement function, `self.bf_d.f`.
        
        #Project displacements back to "real" function space (which may be constrained)
        self.projectDisplacement(self.bf_u.f,self.displacement)
        
        #2018.02.18 - Added for debug purposes
        if self.debug_auxfield:
            self.updateAuxField(self.displacement,self.bf_auxfield.f)
            self.bf_auxfield.update_from()
        
    def F(self, b, x):
        
        self.update_displacement()
        
        return CahnAllenTDP.F(self,b,x)

#--- Typical usage:
#>>> ATS=FT.AdaptiveTimeStepper(CHP,dt=1e-7,L2_increment=.03,solver=solver,min_L2=.01); ATS(10); FT.mplot(CHP.get_soln())

class NotConvergedError(RuntimeError): pass

class AdaptiveTimeStepper(object):
    
    def __init__(self,time_dep_problem,dt,\
                 solver=DefaultNewtonSolver(),\
                 t0=0.,\
                 L2_increment=1e-2,\
                 adaptor=lambda L2: L2,\
                 progress=True,exp_time=False,\
                 u0=None,min_L2=None):
        
        self.problem=time_dep_problem
        self.solver=solver
        
        self.dt=np.float(dt)
        self.dt0=self.dt
        self.t=np.float(t0)
        self.T=self.t+self.dt
        
        self.not_converged_adapt_by=0.1
        self.max_tries_to_converge=10
        
        self.times=[]
        self.solns=[]
        
        self.L2_increment=L2_increment
        self.adaptor=adaptor
        self.adapted=True
        self.adapt=True
        self.u0=u0
        self.min_L2=min_L2
        
        self.update()
        
        if progress:
            self.progress = fenics.Progress('Time-stepping')
            #fenics.set_log_level(fenics.PROGRESS)
        else: self.progress=None
        
        self.t0=t0
        self.exp_time=exp_time
    
    def get_problem(self): return self.problem
    
    def update(self):
        "Store the latest solution and time, and get ready to compute the next solution."
    
        self.times.append(self.t)
        self.solns.append(self.problem.get_soln())
        
        self.adapt_dt()
        self.adapted=True
        
        self.problem.update_initial(self.problem.vector())
        
        self.t+=self.dt
        self.problem.update_time(self.t)
        self.problem.update_dt(self.dt)
    
    def adapt_dt(self):
        
        #Do nothing if we already adapted the time step
        if self.adapted: return
        
        L2=relL2Difference(self.solns[-2],self.solns[-1],\
                           u0=self.u0,min_L2=self.min_L2)
        
        #If L2 is large compared with `self.L2_increment`, 
        # adaptor should return a number < 1.
        adaptation=self.adaptor(self.L2_increment/L2)
        
        self.dt*=adaptation
        
    def step(self):
        
        if self.progress:
            Dt=self.t-self.t0; DT=self.T-self.t0
            if not Dt: prog=0
            elif self.exp_time:
                prog=1+np.log(Dt/DT)/np.log(DT/self.dt0)
            else: prog = Dt/np.float(DT)
            self.progress._assign(prog)
            #self.progress.update(prog)
        
        converged=False
        tries_to_converge=0
        
        while not converged:
            try:
                Logger.write('Stepping with dt=%1.5G.'%self.dt)
                self.solver.solve(self.problem, self.problem.vector())
                converged=True
            
            except RuntimeError:
                if not self.adapt: raise
                
                #Go back half a time step and try again
                self.dt*=self.not_converged_adapt_by
                self.t-=self.dt
                self.problem.update_time(self.t)
                self.problem.update_dt(self.dt)
                
                tries_to_converge+=1
                if tries_to_converge==self.max_tries_to_converge:
                    Logger.warning('Maximum attempts made to converge; aborting time step...')
                    raise NotConvergedError('Maximum attempts made to converge; aborting time step...')
                else: Logger.warning("Didn't converge; reducing time step...")
        
        #Indicate that we're ready to adapt the time-step based on recent solution
        self.adapted=False
        self.update()
        
    def __call__(self,T,L2_increment=None,max_steps=None):
        """Time-step through solutions until time t=`T`.
        
        Optionally, use `L2_increment` as new target for
        the L2 relative difference in adaptive time stepping."""
        
        if L2_increment: self.L2_increment=L2_increment
        self.T=T
        
        self._steps_elapsed=0
        if max_steps is None: max_steps=np.inf
        self.max_steps=max_steps
        
        try:
            while self.t<self.T:
                self._steps_elapsed+=1
                Logger.write('Currently on step %i of %1.2f, at t=%1.5G and stepping towards T=%1.5G.'\
                            %(self._steps_elapsed,self.max_steps,self.t,self.T))
                self.step()
                
                #Break out of time-stepping if 
                if self._steps_elapsed>=self.max_steps:
                    Logger.write('Maximum number of steps (%i) elapsed!'%self.max_steps)
                    break
        except KeyboardInterrupt:
            Logger.error('Interrupted!'); return
        except NotConvergedError:
            Logger.error('Could not converge after %i tries at t=%1.5G!'
                         %(self.max_tries_to_converge,self.t))
            return
            
        Logger.write('Currently at t=%1.5G. Stepping towards T=%1.5G complete!'\
                     %(self.t,self.T))
        
    def to_file(self,path):
        """Write all solutions and times to a .pvd file at `path`."""
        
        file=fenics.File(path,"compressed")
        for pair in zip(self.get_solns(),\
                        self.get_times()): file << pair
        
    def to_h5_file(self,path,mode='a',\
                   mesh_path='mesh.xml',\
                   precision=8):
        
        mesh=self.get_soln(self.t).function_space().mesh()
        fenics.File(mesh_path) << mesh
        
        import h5py
        with h5py.File(path,mode) as f:
        
            for soln,time in zip(self.get_solns(),\
                                 self.get_times()):
                
                time_str='%1.*f'%(precision,time)
                if time_str in list(f.keys()): del f[time_str]
                f.create_dataset(time_str, data=soln.vector().get_local())
            
            fs_key='function_space'
            if fs_key in list(f.keys()): del f[fs_key]
            f.create_dataset(fs_key,data=np.string_(soln.function_space()))
            
    def from_h5_file(self,path):
        """Load times and solutions from an HDF5 file.
        
        Solution vectors in the HDF5 file must be of appropriate
        size to match the solution function space (and mesh) of
        the current problem.
        
        If loading is successful, this will overwrite times and
        solutions already stored by `AdaptiveTimeStepper`."""
        
        V=self.problem.get_soln().function_space()
        
        def is_time(key):
            
            try:
                float(key); return True
            except ValueError: return False
        
        import h5py
        with h5py.File(path,'r') as f:
        
            try:
                Logger.write('Loading from function space `%s`...'\
                             %repr(f['function_space'].value))
            except KeyError:
                Logger.write('Loading from unknown function space...')
                
            times=sorted(filter(is_time,list(f.keys())))
            times_to_keep=copy.copy(times)
            
            solns=[]
            for time in times:
                u=fenics.Function(V)
                try:
                    u.vector()[:]=f[time][:]
                    solns.append(u)
                    
                except IndexError:
                    times_to_keep.pop(time)
                    
            self.solns=solns
            self.times=[float(time) for time \
                        in times_to_keep]
            
            Logger.write('%i of %i solutions successfully loaded!'%\
                         (len(times_to_keep),len(times)))
    
    def get_times(self): return np.array(self.times)
        
    def get_solns(self): return self.solns
    
    def get_soln(self,t=None):
        """Get the solution closest in time to `t`."""
        
        if t is None: t=self.get_times()[-1]
        ind=np.argmin((self.get_times()-t)**2)
        
        return self.get_solns()[ind]